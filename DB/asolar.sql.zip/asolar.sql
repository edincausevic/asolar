-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 03, 2018 at 09:49 PM
-- Server version: 10.1.25-MariaDB
-- PHP Version: 5.6.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `asolar`
--

-- --------------------------------------------------------

--
-- Table structure for table `artikli`
--

CREATE TABLE `artikli` (
  `id` int(12) NOT NULL,
  `menu_id` int(12) NOT NULL,
  `ime` varchar(255) NOT NULL,
  `slika` varchar(255) NOT NULL,
  `kratki_opis` text NOT NULL,
  `cijena` float NOT NULL,
  `opis` text NOT NULL,
  `pregledan` int(7) NOT NULL DEFAULT '0',
  `izdvojeno` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `artikli`
--

INSERT INTO `artikli` (`id`, `menu_id`, `ime`, `slika`, `kratki_opis`, `cijena`, `opis`, `pregledan`, `izdvojeno`) VALUES
(2, 12, 'Wifi A53', 'wifi-ip-kamera-nocno-snimanje-alarm-video-nadzorr-slika-21704057-500x500.jpg', 'Wifi Kamera', 46, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. In pellentesque eu diam quis consectetur. Interdum et malesuada fames ac ante ipsum primis in faucibus. Ut vitae tellus est. Vestibulum pulvinar mi turpis, quis interdum est semper sit amet. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Praesent est elit, tincidunt sed nisl ut, posuere placerat tortor. Curabitur laoreet nisl ligula, sed egestas leo euismod in. Proin dapibus a tortor ut feugiat. Aliquam nec consequat enim. In ut consequat velit, nec fringilla urna. Nunc interdum porta ante nec auctor. Vestibulum ac interdum mauris. Aenean bibendum massa non dictum luctus.\r\n\r\nNunc nec pretium risus, non ultrices sapien. Integer tincidunt aliquam odio, sed elementum sem pharetra at. Maecenas sit amet aliquam urna, nec aliquam lacus. Integer scelerisque lobortis libero non suscipit. Donec pellentesque eu ante nec imperdiet. Duis sem elit, viverra nec erat vel, dignissim efficitur elit. Aenean fermentum purus mauris, ut iaculis lectus feugiat ac. Pellentesque finibus, risus id mollis suscipit, felis quam suscipit neque, in pretium dolor ante lobortis ante.\r\n\r\nEtiam felis velit, malesuada eu ante non, vestibulum accumsan ante. Vestibulum id risus suscipit, blandit ipsum sit amet, finibus ex. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam sem ligula, feugiat vitae tincidunt convallis, lobortis in turpis. In et nulla at diam congue gravida quis non purus. Nulla facilisi. Aenean orci mi, ornare in arcu non, commodo malesuada felis. Aliquam dictum elit id euismod condimentum. Vestibulum eget consectetur leo. Fusce mollis mi sit amet turpis scelerisque, ac bibendum nunc ultrices. Morbi aliquam lacus in dui mattis sollicitudin. Fusce nec odio nec sapien accumsan tristique. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Aenean sit amet massa consectetur, gravida ligula eu, tempor nisl.\r\n\r\nEtiam porttitor ac sem non cursus. Aenean maximus sapien vitae justo facilisis consectetur. Nam nec sagittis ante. Etiam eget metus vitae neque porta dapibus. Nulla imperdiet posuere nibh, id auctor enim tempor a. Duis non molestie metus. Pellentesque suscipit lacus ac eleifend mattis. Morbi eu arcu quis nisi commodo mattis sit amet sit amet libero. Duis consectetur viverra ornare. Cras pretium urna in urna bibendum fringilla. Sed sit amet convallis nunc.\r\n\r\nMauris congue porta lectus et dictum. Vestibulum imperdiet lorem at egestas consequat. Suspendisse potenti. Aliquam vel euismod nulla. Sed eget justo in nunc malesuada commodo sed quis justo. Vestibulum eget pulvinar sapien. Praesent iaculis massa ex, hendrerit placerat ante tincidunt non. Curabitur justo arcu, volutpat id mauris accumsan, congue consequat est. Nam fringilla, est at fermentum hendrerit, justo diam blandit nisl, sed facilisis erat eros ac ligula. Ut pulvinar diam sed volutpat suscipit. Sed tristique consectetur tincidunt. Nulla vitae felis iaculis, tincidunt neque ac, blandit lectus. Aliquam ac condimentum urna.', 0, 1),
(3, 12, 'WIFI CAM', 'wifi-ip-kamera-nocno-snimanje-alarm-video-nadzorr-slika-21704057-500x500.jpg', 'Wifi Kamera', 76, 'Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Praesent est elit, tincidunt sed nisl ut, posuere placerat tortor. Curabitur laoreet nisl ligula, sed egestas leo euismod in. Proin dapibus a tortor ut feugiat. Aliquam nec consequat enim. In ut consequat velit, nec fringilla urna. Nunc interdum porta ante nec auctor. Vestibulum ac interdum mauris. Aenean bibendum massa non dictum luctus.\r\n\r\nNunc nec pretium risus, non ultrices sapien. Integer tincidunt aliquam odio, sed elementum sem pharetra at. Maecenas sit amet aliquam urna, nec aliquam lacus. Integer scelerisque lobortis libero non suscipit. Donec pellentesque eu ante nec imperdiet. Duis sem elit, viverra nec erat vel, dignissim efficitur elit. Aenean fermentum purus mauris, ut iaculis lectus feugiat ac. Pellentesque finibus, risus id mollis suscipit, felis quam suscipit neque, in pretium dolor ante lobortis ante.\r\n\r\nEtiam felis velit, malesuada eu ante non, vestibulum accumsan ante. Vestibulum id risus suscipit, blandit ipsum sit amet, finibus ex. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam sem ligula, feugiat vitae tincidunt convallis, lobortis in turpis. In et nulla at diam congue gravida quis non purus. Nulla facilisi. Aenean orci mi, ornare in arcu non, commodo malesuada felis. Aliquam dictum elit id euismod condimentum. Vestibulum eget consectetur leo. Fusce mollis mi sit amet turpis scelerisque, ac bibendum nunc ultrices. Morbi aliquam lacus in dui mattis sollicitudin. Fusce nec odio nec sapien accumsan tristique. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Aenean sit amet massa consectetur, gravida ligula eu, tempor nisl.\r\n\r\nEtiam porttitor ac sem non cursus. Aenean maximus sapien vitae justo facilisis consectetur. Nam nec sagittis ante. Etiam eget metus vitae neque porta dapibus. Nulla imperdiet posuere nibh, id auctor enim tempor a. Duis non molestie metus. Pellentesque suscipit lacus ac eleifend mattis. Morbi eu arcu quis nisi commodo mattis sit amet sit amet libero. Duis consectetur viverra ornare. Cras pretium urna in urna bibendum fringilla. Sed sit amet convallis nunc.\r\n\r\nMauris congue porta lectus et dictum. Vestibulum imperdiet lorem at egestas consequat. Suspendisse potenti. Aliquam vel euismod nulla. Sed eget justo in nunc malesuada commodo sed quis justo. Vestibulum eget pulvinar sapien. Praesent iaculis massa ex, hendrerit placerat ante tincidunt non. Curabitur justo arcu, volutpat id mauris accumsan, congue consequat est. Nam fringilla, est at fermentum hendrerit, justo diam blandit nisl, sed facilisis erat eros ac ligula. Ut pulvinar diam sed volutpat suscipit. Sed tristique consectetur tincidunt. Nulla vitae felis iaculis, tincidunt neque ac, blandit lectus. Aliquam ac condimentum urna.', 1, 0),
(5, 12, 'A54', 'micro-wifi-kamera.jpg', 'Wifi Kamera', 42, 'Aliquam nec consequat enim. In ut consequat velit, nec fringilla urna. Nunc interdum porta ante nec auctor. Vestibulum ac interdum mauris. Aenean bibendum massa non dictum luctus.\r\n\r\nNunc nec pretium risus, non ultrices sapien. Integer tincidunt aliquam odio, sed elementum sem pharetra at. Maecenas sit amet aliquam urna, nec aliquam lacus. Integer scelerisque lobortis libero non suscipit. Donec pellentesque eu ante nec imperdiet. Duis sem elit, viverra nec erat vel, dignissim efficitur elit. Aenean fermentum purus mauris, ut iaculis lectus feugiat ac. Pellentesque finibus, risus id mollis suscipit, felis quam suscipit neque, in pretium dolor ante lobortis ante.\r\n\r\nEtiam felis velit, malesuada eu ante non, vestibulum accumsan ante. Vestibulum id risus suscipit, blandit ipsum sit amet, finibus ex. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam sem ligula, feugiat vitae tincidunt convallis, lobortis in turpis. In et nulla at diam congue gravida quis non purus. Nulla facilisi. Aenean orci mi, ornare in arcu non, commodo malesuada felis. Aliquam dictum elit id euismod condimentum. Vestibulum eget consectetur leo. Fusce mollis mi sit amet turpis scelerisque, ac bibendum nunc ultrices. Morbi aliquam lacus in dui mattis sollicitudin. Fusce nec odio nec sapien accumsan tristique. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Aenean sit amet massa consectetur, gravida ligula eu, tempor nisl.\r\n\r\nEtiam porttitor ac sem non cursus. Aenean maximus sapien vitae justo facilisis consectetur. Nam nec sagittis ante. Etiam eget metus vitae neque porta dapibus. Nulla imperdiet posuere nibh, id auctor enim tempor a. Duis non molestie metus. Pellentesque suscipit lacus ac eleifend mattis. Morbi eu arcu quis nisi commodo mattis sit amet sit amet libero. Duis consectetur viverra ornare. Cras pretium urna in urna bibendum fringilla. Sed sit amet convallis nunc.\r\n\r\nMauris congue porta lectus et dictum. Vestibulum imperdiet lorem at egestas consequat. Suspendisse potenti. Aliquam vel euismod nulla. Sed eget justo in nunc malesuada commodo sed quis justo. Vestibulum eget pulvinar sapien. Praesent iaculis massa ex, hendrerit placerat ante tincidunt non. Curabitur justo arcu, volutpat id mauris accumsan, congue consequat est. Nam fringilla, est at fermentum hendrerit, justo diam blandit nisl, sed facilisis erat eros ac ligula. Ut pulvinar diam sed volutpat suscipit. Sed tristique consectetur tincidunt. Nulla vitae felis iaculis, tincidunt neque ac, blandit lectus. Aliquam ac condimentum urna.', 3, 0),
(6, 12, 'CAM', 'IP-kamera-wifi.jpg', 'Wifi Kamera', 55, 'Nam fringilla, est at fermentum hendrerit, justo diam blandit nisl, sed facilisis erat eros ac ligula. Ut pulvinar diam sed volutpat suscipit. Sed tristique consectetur tincidunt. Nulla vitae felis iaculis, tincidunt neque ac, blandit lectus. Aliquam ac condimentum urna.', 0, 1),
(7, 9, 'H4', '48102.jpg', 'Led Sijelica', 5, 'Ut sit amet ligula lorem. Aliquam volutpat libero cursus, dapibus purus facilisis, hendrerit mi. Etiam et purus non erat tempus dignissim. Nunc sodales massa sed est dictum, lobortis convallis ex pellentesque. Nunc placerat consequat est at ultricies. Fusce feugiat quis ipsum sed mollis. Vivamus id velit eleifend massa faucibus auctor. Nulla commodo mauris vitae aliquam pretium. Phasellus convallis ut ex sed sollicitudin. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae;', 1, 1),
(9, 9, 'H7', '37e5ad01679226e5d1a4e0ffe4.jpg', 'Sijelica', 4, 'Donec hendrerit varius nibh, ut cursus erat hendrerit eget. Curabitur hendrerit felis sagittis risus efficitur tincidunt. In non sem tellus. Nullam venenatis semper magna, nec efficitur nisi pellentesque non. Praesent ornare sem mollis libero interdum mollis. Praesent faucibus ornare mattis. Nunc ut leo eget risus sollicitudin volutpat a non purus. Curabitur ultricies quam eget nisi iaculis hendrerit. Nunc diam felis, vehicula eget lectus at, consectetur convallis justo.', 1, 0),
(11, 7, 'Energizer', 'fawfwf.jpg', 'Energizer Premium', 55, 'In in hendrerit mauris, ut malesuada mi. Nunc mattis nulla neque, vitae interdum nisl viverra sed. Maecenas lacinia, elit id pretium molestie, dui dui sollicitudin orci, id vestibulum mauris massa maximus lacus. Aenean et turpis id metus accumsan vehicula. Praesent rhoncus semper sodales. ', 1, 1),
(12, 7, 'Bosch S3', 'tawe.jpg', 'Akomulator', 55, 'Proin eu mauris nisl. Proin sapien purus, maximus laoreet risus nec, eleifend bibendum sem. Nullam a volutpat tortor. Mauris sed blandit risus. Mauris pretium lectus vel tincidunt blandit. Interdum et malesuada fames ac ante ipsum primis in faucibus. Etiam volutpat enim ac mattis gravida. Sed viverra elementum dolor, a pulvinar nisi. Nunc tristique pellentesque elit, vitae interdum augue posuere eu. Vivamus ornare congue elit, nec blandit quam semper vel. Proin hendrerit nunc nulla, eu sodales tellus accumsan nec. Sed vitae rutrum diam.', 6, 0),
(13, 7, 'Youasa', 'fawfwf.jpg', 'Youasa 3000', 56, 'Maecenas sit amet aliquam urna, nec aliquam lacus. Integer scelerisque lobortis libero non suscipit. Donec pellentesque eu ante nec imperdiet. Duis sem elit, viverra nec erat vel, dignissim efficitur elit. Aenean fermentum purus mauris, ut iaculis lectus feugiat ac. Pellentesque finibus, risus id mollis suscipit, felis quam suscipit neque, in pretium dolor ante lobortis ante.\r\n \r\n ', 1, 0),
(18, 5, 'DE3', '34173cb38f07f89ddbebc2ac9128303f.jpg', 'PN', 12, 'Morbi tempor metus quis turpis scelerisque imperdiet. In vestibulum ultrices lobortis. Duis et ante fermentum eros finibus placerat. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Proin quis nisl eleifend, luctus arcu eu, dignissim sem.', 0, 1),
(19, 10, 'Kablovi', '14bfa6bb14875e45bba028a21ed38046.jpg', 'SSO', 53, 'Morbi tempor metus quis turpis scelerisque imperdiet. In vestibulum ultrices lobortis. Duis et ante fermentum eros finibus placerat. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Proin quis nisl eleifend, luctus arcu eu, dignissim sem.', 0, 1),
(20, 2, 'Regularor', '7f39f8317fbdb1988ef4c628eba02591.jpg', 'SR', 23, 'Morbi tempor metus quis turpis scelerisque imperdiet. In vestibulum ultrices lobortis. Duis et ante fermentum eros finibus placerat. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Proin quis nisl eleifend, luctus arcu eu, dignissim sem.', 0, 1),
(21, 1, 'Paneli', '182be0c5cdcd5072bb1864cdee4d3d6e.jpg', 'SP', 43, 'Maecenas iaculis urna nec imperdiet congue. Aliquam non rutrum mi, nec pulvinar nisi. Vivamus varius augue vitae sagittis vulputate. Praesent fermentum quam nisl, congue facilisis nunc congue et. Phasellus neque tellus, vestibulum at erat ornare, pulvinar posuere metus. Maecenas tincidunt maximus purus quis dictum. Nunc condimentum venenatis porttitor. Nunc ex magna, pretium nec aliquam eget, porttitor id purus. Ut tristique mi vitae dignissim dignissim. Proin dictum tempus nisl, et iaculis turpis vehicula euismod. Nunc ac turpis ac lorem sagittis tincidunt. Curabitur convallis quam eu augue lobortis cursus. Mauris accumsan euismod velit aliquam tristique.', 0, 0),
(22, 11, 'Sol', '8e296a067a37563370ded05f5a3bf3ec.jpg', 'Ulicne svijetiljke', 53, 'Maecenas iaculis urna nec imperdiet congue. Aliquam non rutrum mi, nec pulvinar nisi. Vivamus varius augue vitae sagittis vulputate. Praesent fermentum quam nisl, congue facilisis nunc congue et. Phasellus neque tellus, vestibulum at erat ornare, pulvinar posuere metus. Maecenas tincidunt maximus purus quis dictum. Nunc condimentum venenatis porttitor. Nunc ex magna, pretium nec aliquam eget, porttitor id purus. Ut tristique mi vitae dignissim dignissim. Proin dictum tempus nisl, et iaculis turpis vehicula euismod. Nunc ac turpis ac lorem sagittis tincidunt. Curabitur convallis quam eu augue lobortis cursus. Mauris accumsan euismod velit aliquam tristique.', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `artikli_menu`
--

CREATE TABLE `artikli_menu` (
  `id` int(12) NOT NULL,
  `ime` varchar(255) NOT NULL,
  `route` varchar(255) NOT NULL,
  `pregledan` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `artikli_menu`
--

INSERT INTO `artikli_menu` (`id`, `ime`, `route`, `pregledan`) VALUES
(1, 'Solarni paneli', 'solarni-paneli', 5),
(2, 'Solarni regulatori', 'solarni-regulatori', 5),
(5, 'Pretvaraci napona', 'pretvaraci-napona', 5),
(7, 'Akomulatori', 'akomulatori', 15),
(9, 'Led sijelice', 'led-sijelice', 6),
(10, 'Sitna solarna oprema', 'sitna-solarna-oprema', 5),
(11, 'Solarne ulicne svijetiljke', 'solarne-ulicne-svijetiljke', 4),
(12, 'Wifi kamere', 'wifi-kamere', 5);

-- --------------------------------------------------------

--
-- Table structure for table `korisnik`
--

CREATE TABLE `korisnik` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `broj_telefona` varchar(15) NOT NULL,
  `radno_vrijeme` varchar(20) NOT NULL,
  `adresa` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `korisnik`
--

INSERT INTO `korisnik` (`id`, `username`, `password`, `email`, `broj_telefona`, `radno_vrijeme`, `adresa`) VALUES
(2, 'admin', 'admin', 'admin@email.com', '000 000 000', '09:00 do 15:00 h', 'Carsija 52, Bosanska Otoka');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `artikli`
--
ALTER TABLE `artikli`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `artikli_menu`
--
ALTER TABLE `artikli_menu`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `korisnik`
--
ALTER TABLE `korisnik`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `artikli`
--
ALTER TABLE `artikli`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;
--
-- AUTO_INCREMENT for table `artikli_menu`
--
ALTER TABLE `artikli_menu`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `korisnik`
--
ALTER TABLE `korisnik`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
